using System.ComponentModel;
using Terraria.ModLoader.Config;

namespace Blinking
{
    [Label("Server Config")]
    public class BlinkingConfig : ModConfig
    {
        //This is here for the Config to work at all.
        public override ConfigScope Mode => ConfigScope.ServerSide;
		
        public static BlinkingConfig Instance;
		
        [Header("General")]
		
        [Label("Enable Blinking")]
        [Tooltip("If false, Players cannot Blink.\n[Default: On]")]
        [DefaultValue(true)]
        public bool enableBlinking {get; set;}
		
        [Label("Enable Manual Blinking")]
        [Tooltip("If false, Players cannot manually Blink.\n[Default: On]")]
        [DefaultValue(true)]
        public bool enableManualBlinking {get; set;}
		
        [Label("Enable Automatic Blinking")]
        [Tooltip("If false, Players will not automatically Blink.\n[Default: On]")]
        [DefaultValue(true)]
        public bool enableAutomaticBlinking {get; set;}
		
        [Label("Enable Blinking From Damage")]
        [Tooltip("If false, Players will not Blink when receiving damage.\n[Default: On]")]
        [DefaultValue(true)]
        public bool enableBlinkingFromDamage {get; set;}
		
        [Label("Blink Timer")]
        [Tooltip("How long Blinking lasts.\n[Default: 5]")]
        [Slider]
        [DefaultValue(5)]
        [Range(5, 40)]
        [Increment(5)]
        public int blinkTimer {get; set;}
		
        [Label("Blink Cooldown")]
        [Tooltip("How long until Automatic Blinking occurs.\n[Default: 210]")]
        [Slider]
        [DefaultValue(210)]
        [Range(30, 600)]
        [Increment(30)]
        public int blinkCooldown {get; set;}
		
        [Header("Effects")]
		
        [Label("Apply Blackout Effect")]
        [Tooltip("If true, upon Blinking, the Player's vision will be moderately reduced.\n(Disabling this removes the Blinking visual effect completely. I need to fix this.)\n[Default: On]")]
        [DefaultValue(true)]
        public bool applyBlackout {get; set;}
		
        [Label("Apply Obstructed Debuff")]
        [Tooltip("If true, upon Blinking, the Player's vision will be drastically reduced down to a small circle.\n[Default: On]")]
        [DefaultValue(true)]
        public bool applyObstructed {get; set;}
    }
}