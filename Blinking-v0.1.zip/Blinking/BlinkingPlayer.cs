﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.GameContent;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.Audio;
using System.Runtime.CompilerServices;

namespace Blinking
{
    public class BlinkingPlayer : ModPlayer
    {
		public int blinkTimer = 0;
		public int blinkCooldown = BlinkingConfig.Instance.blinkCooldown;
		
		public static BlinkingPlayer ModPlayer(Player Player)
		{
			return Player.GetModPlayer<BlinkingPlayer>();
		}
		
		public override void PostUpdateMiscEffects() //Core.
		{
			//Various attempts to get this working are below.
			//PlayerTextureID = PlayerTextureID.EyeBlink;
			//PlayerTextureID playerTexID = PlayerTextureID.EyeBlink;
			//PlayerTextureID.EyeBlink;
			//PlayerEyeHelper.EyeFrameToShow = PlayerTextureID.EyeBlink;
			//PlayerEyeHelper.EyeFrameToShow == PlayerEyeHelper.EyeFrame.EyeClosed;
			//_state == EyeState.JustTookDamage;
			//PlayerEyeHelper._state = 1;
			//PlayerEyeHelper.EyeState = 1;
			//PlayerEyeHelper.EyeFrameToShow == 1;
			//Player.eyeHelper.EyeFrameToShow = 1;
			
			
			//Manual Blinking
			if (Blinking.Blink.Current && BlinkingConfig.Instance.enableBlinking && BlinkingConfig.Instance.enableManualBlinking)
			{
				blinkTimer = BlinkingConfig.Instance.blinkTimer;
				blinkCooldown = BlinkingConfig.Instance.blinkCooldown;
				if (BlinkingConfig.Instance.applyBlackout)
				{
					Player.blackout = true;
				}
				if (BlinkingConfig.Instance.applyObstructed)
				{
					Player.AddBuff(BuffID.Obstructed, BlinkingConfig.Instance.blinkTimer);
				}
			}
			if (Blinking.Blink.JustPressed && BlinkingConfig.Instance.enableBlinking && BlinkingConfig.Instance.enableManualBlinking)
			{
			}
			//Automatic Blinking
			if (blinkCooldown <= 0 && BlinkingConfig.Instance.enableBlinking && BlinkingConfig.Instance.enableAutomaticBlinking)
			{
				blinkTimer = BlinkingConfig.Instance.blinkTimer;
				blinkCooldown = BlinkingConfig.Instance.blinkCooldown;
			}
			else if (BlinkingConfig.Instance.enableBlinking)
			{
				blinkCooldown--;
			}
			//Blink Timer (How long to Blink.)
			if (blinkTimer > 0 && BlinkingConfig.Instance.enableBlinking && BlinkingConfig.Instance.enableAutomaticBlinking)
			{
				blinkTimer--;
				if (BlinkingConfig.Instance.applyBlackout)
				{
					Player.blackout = true;
				}
				if (BlinkingConfig.Instance.applyObstructed)
				{
					Player.AddBuff(BuffID.Obstructed, BlinkingConfig.Instance.blinkTimer);
				}
			}
		}
		
		public override void PostHurt(bool pvp, bool quiet, double damage, int hitDirection, bool crit)
        {
			if (BlinkingConfig.Instance.enableBlinkingFromDamage)
			{
				blinkTimer = BlinkingConfig.Instance.blinkTimer;
				blinkCooldown = BlinkingConfig.Instance.blinkCooldown;
				if (BlinkingConfig.Instance.applyBlackout)
				{
					Player.blackout = true;
				}
				if (BlinkingConfig.Instance.applyObstructed)
				{
					Player.AddBuff(BuffID.Obstructed, BlinkingConfig.Instance.blinkTimer);
				}
			}
        }
	}
}